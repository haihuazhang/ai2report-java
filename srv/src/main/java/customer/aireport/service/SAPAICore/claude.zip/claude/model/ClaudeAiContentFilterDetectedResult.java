package customer.aireport.service.SAPAICore.claude.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.annotations.Beta;
import javax.annotation.Nonnull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;

/** OpenAI content filter detected result. */
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Beta
public class ClaudeAiContentFilterDetectedResult extends ClaudeAiContentFilterResultBase {
  /** Whether the content was detected. */
  @JsonProperty("detected")
  @Getter(onMethod = @__(@Nonnull))
  private boolean detected;
}
